package utils;

public class MathUtils {
    public static int sum(int x, int y) {
        return x + y;
    }
}